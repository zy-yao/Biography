---
draft: false
header:
  caption: ""
  image: house_price.jpg
title: House Price Prediction
date: 2018-12-01T14:13:20.999Z
featured: false
external_link: https://www.zhongyu.site/files/Kaggle_Competition_%20House%20Prices_Advanced_Regression.pdf
links:
  - url: https://www.kaggle.com/c/house-prices-advanced-regression-techniques
    name: Introduction to the competition
image:
  filename: featured
  focal_point: Smart
  preview_only: false
---


![](house_price.jpg)

We use advanced regression analysis to predict the price data of a state of USA.